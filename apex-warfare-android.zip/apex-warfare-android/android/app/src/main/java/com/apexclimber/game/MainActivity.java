package com.apexclimber.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
