import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.apexclimber.game',
  appName: 'Apex Climber',
  webDir: 'dist/public'
};

export default config;
