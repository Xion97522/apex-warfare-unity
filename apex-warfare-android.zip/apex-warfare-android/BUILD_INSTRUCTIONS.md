# Apex Warfare - Android APK Build Guide

## Quick Start (Automatic - GitHub Actions)

The easiest way is to use GitHub Actions to build automatically:

1. **Push to GitHub** (see main README for instructions)
2. **Enable GitHub Actions** in your repository settings
3. **The workflow will automatically build the APK**
4. **Download from Actions tab**

---

## Build Locally (Manual)

### Requirements

- **Java Development Kit (JDK) 11+**
  - Download: https://www.oracle.com/java/technologies/javase-jdk11-downloads.html
  - Or: `brew install openjdk` (Mac) / `apt install openjdk-11-jdk` (Linux)

- **Android SDK**
  - Download Android Studio: https://developer.android.com/studio
  - Or use `sdkmanager` if you have it installed

- **Node.js & npm**

### Build Steps

```bash
# 1. Install dependencies
npm install

# 2. Build the web app
npm run build

# 3. Sync with Android
npx cap sync android

# 4. Build the APK
cd android
./gradlew assembleDebug

# 5. Find your APK
# Output: android/app/build/outputs/apk/debug/app-debug.apk
```

### Build for Release (Signed)

```bash
cd android
./gradlew assembleRelease

# Output: android/app/build/outputs/apk/release/app-release-unsigned.apk

# You'll need to sign it with your keystore
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore my-release-key.keystore \
  app-release-unsigned.apk alias_name
```

---

## GitHub Actions Auto-Build

Add this workflow file to `.github/workflows/build-android.yml`:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    
    - name: Set up JDK
      uses: actions/setup-java@v3
      with:
        java-version: '11'
        distribution: 'adopt'
    
    - name: Install dependencies
      run: npm install
    
    - name: Build web app
      run: npm run build
    
    - name: Sync Capacitor
      run: npx cap sync android
    
    - name: Build APK
      run: cd android && ./gradlew assembleDebug
    
    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: Apex-Warfare-Debug.apk
        path: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Installation on Android Phone

1. **Enable Developer Mode**
   - Settings → About → Tap Build Number 7 times

2. **Enable USB Debugging**
   - Settings → Developer Options → USB Debugging

3. **Connect via USB**
   ```bash
   adb install app-debug.apk
   ```

4. **Or install manually**
   - Copy APK to phone via USB
   - Open file manager and tap the APK to install

---

## Troubleshooting

### Gradle build fails
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

### Java version error
```bash
export JAVA_HOME=/path/to/jdk11
./gradlew assembleDebug
```

### Capacitor sync issues
```bash
npx cap update
npx cap sync android --deployment
```

---

## What's Included

- ✅ Full Apex Warfare game
- ✅ 60-144 FPS optimized
- ✅ Drivable cars
- ✅ Radio system (25 songs)
- ✅ Offline gameplay
- ✅ Touch controls ready

---

Enjoy Apex Warfare on Android! 🎮📱
