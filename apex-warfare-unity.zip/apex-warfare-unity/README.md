# Apex Warfare - Unity Edition

A 3D open-world shooter game built with Unity featuring drivable cars, in-game radio system, and GTA V-style gameplay.

## Features

- **Player Movement**: WASD for movement, mouse to look around, Space to jump
- **Drivable Cars**: Press E to enter/exit cars, WASD to drive
- **Radio System**: 25 songs across 5 genres (Combat, Ambient, Rock, Electronic, Classical)
- **3D Environment**: Blue sky, green terrain, multiple drivable vehicles
- **GTA V-style Lobby**: "APEX WARFARE" title display

## Controls

- **W** - Move Forward
- **S** - Move Backward
- **A** - Strafe Left
- **D** - Strafe Right
- **Space** - Jump
- **E** - Enter/Exit Vehicle
- **Mouse** - Look Around

## Project Structure

```
Assets/
├── Scripts/
│   ├── Game/
│   │   └── GameManager.cs
│   ├── Player/
│   │   ├── PlayerController.cs
│   │   └── PlayerCarInteraction.cs
│   ├── Cars/
│   │   └── CarController.cs
│   ├── UI/
│   │   └── GameHUD.cs
│   ├── Camera/
│   │   └── CameraFollower.cs
│   └── Radio/
│       ├── RadioSystem.cs
│       └── Song.cs
├── Scenes/
├── Resources/
└── Prefabs/
```

## Setup Instructions

1. Open the project in Unity 2022.3 or later
2. Create a new scene named "GameScene"
3. Create an empty GameObject and add the GameManager script
4. Create a UI Canvas for the GameHUD
5. Add a TextMeshPro text element for the title display
6. Press Play to start the game

## Performance

- Optimized for 60-144 FPS
- Simple box-based geometry for fast rendering
- Efficient physics with Rigidbody components

## Audio

To add music:
1. Place audio files in `Assets/Resources/Music`
2. Update the RadioSystem.cs InitializeSongs() method to load the clips:
   ```csharp
   clip = Resources.Load<AudioClip>("Music/song_name")
   ```

## License

Created for Apex Warfare project
