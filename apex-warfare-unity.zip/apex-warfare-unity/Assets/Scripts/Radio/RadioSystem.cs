using UnityEngine;
using System.Collections.Generic;

public class RadioSystem : MonoBehaviour
{
    private AudioSource audioSource;
    private List<Song> songs = new List<Song>();
    private int currentIndex = 0;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
        InitializeSongs();
    }

    private void InitializeSongs()
    {
        // Combat Genre
        AddSong("Battle Cry", "WarMaster", "Combat");
        AddSong("Assault", "ActionBeats", "Combat");
        AddSong("Siege", "HeavyHits", "Combat");
        AddSong("Victory", "Champions", "Combat");
        AddSong("Rampage", "Explosive", "Combat");

        // Ambient Genre
        AddSong("Serenity", "Zenith", "Ambient");
        AddSong("Drift", "Ethereal", "Ambient");
        AddSong("Nebula", "Cosmic", "Ambient");
        AddSong("Echo", "Reflective", "Ambient");
        AddSong("Horizon", "Distant", "Ambient");

        // Rock Genre
        AddSong("The Box", "Roddy Ricch", "Rock");
        AddSong("Thunder Road", "RockLegends", "Rock");
        AddSong("Burning Sky", "FireStorm", "Rock");
        AddSong("Electric", "PowerChords", "Rock");
        AddSong("Unleashed", "WildSpirit", "Rock");

        // Electronic Genre
        AddSong("Neon City", "SynthWave", "Electronic");
        AddSong("Digital Dreams", "TechBeat", "Electronic");
        AddSong("Cyber Pulse", "NeonPulse", "Electronic");
        AddSong("Future Now", "ElectroShock", "Electronic");
        AddSong("Grid", "PixelBeat", "Electronic");

        // Classical Genre
        AddSong("Symphony No.1", "Maestro", "Classical");
        AddSong("Moonlight Sonata", "Classical Masters", "Classical");
        AddSong("Grand Finale", "Orchestra", "Classical");
        AddSong("Timeless", "Composer", "Classical");
        AddSong("Elegance", "String Quartet", "Classical");
    }

    private void AddSong(string title, string artist, string genre)
    {
        Song song = new Song
        {
            title = title,
            artist = artist,
            genre = genre,
            clip = null // In real project, load AudioClips from Resources
        };
        songs.Add(song);
    }

    public void PlaySong(int index)
    {
        if (index >= 0 && index < songs.Count)
        {
            currentIndex = index;
            // Play audio if clip exists
            if (songs[currentIndex].clip != null)
            {
                audioSource.clip = songs[currentIndex].clip;
                audioSource.Play();
            }
            Debug.Log($"Now Playing: {songs[currentIndex].title}");
        }
    }

    public Song GetCurrentSong()
    {
        return songs[currentIndex];
    }

    public int GetSongCount()
    {
        return songs.Count;
    }

    public void NextSong()
    {
        currentIndex = (currentIndex + 1) % songs.Count;
        PlaySong(currentIndex);
    }

    public void PreviousSong()
    {
        currentIndex--;
        if (currentIndex < 0)
            currentIndex = songs.Count - 1;
        PlaySong(currentIndex);
    }
}
