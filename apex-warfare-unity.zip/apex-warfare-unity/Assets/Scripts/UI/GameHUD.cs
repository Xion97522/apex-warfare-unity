using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class GameHUD : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI radioDisplay;
    [SerializeField] private Button nextSongButton;
    [SerializeField] private Button prevSongButton;

    private RadioSystem radioSystem;
    private int currentSongIndex = 0;

    private void Start()
    {
        radioSystem = FindObjectOfType<RadioSystem>();
        
        if (titleText != null)
        {
            titleText.text = "APEX WARFARE";
            titleText.alignment = TextAlignmentOptions.Center;
        }

        if (nextSongButton != null)
            nextSongButton.onClick.AddListener(NextSong);
        if (prevSongButton != null)
            prevSongButton.onClick.AddListener(PrevSong);

        UpdateRadioDisplay();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            UpdateRadioDisplay();
        }
    }

    private void NextSong()
    {
        if (radioSystem != null)
        {
            currentSongIndex = (currentSongIndex + 1) % radioSystem.GetSongCount();
            radioSystem.PlaySong(currentSongIndex);
            UpdateRadioDisplay();
        }
    }

    private void PrevSong()
    {
        if (radioSystem != null)
        {
            currentSongIndex--;
            if (currentSongIndex < 0)
                currentSongIndex = radioSystem.GetSongCount() - 1;
            radioSystem.PlaySong(currentSongIndex);
            UpdateRadioDisplay();
        }
    }

    private void UpdateRadioDisplay()
    {
        if (radioSystem != null && radioDisplay != null)
        {
            Song currentSong = radioSystem.GetCurrentSong();
            radioDisplay.text = $"🎵 {currentSong.title} - {currentSong.artist}\nGenre: {currentSong.genre}";
        }
    }
}
