using UnityEngine;

public class PlayerCarInteraction : MonoBehaviour
{
    private CarController currentCar = null;
    private float interactionRange = 5f;

    public void TryEnterCar()
    {
        if (currentCar != null)
        {
            currentCar.ExitCar(transform);
            currentCar = null;
            return;
        }

        // Find nearest car
        CarController[] cars = FindObjectsOfType<CarController>();
        CarController nearestCar = null;
        float nearestDistance = interactionRange;

        foreach (CarController car in cars)
        {
            float distance = Vector3.Distance(transform.position, car.transform.position);
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                nearestCar = car;
            }
        }

        if (nearestCar != null)
        {
            currentCar = nearestCar;
            currentCar.EnterCar(transform);
        }
    }

    public CarController GetCurrentCar()
    {
        return currentCar;
    }
}
