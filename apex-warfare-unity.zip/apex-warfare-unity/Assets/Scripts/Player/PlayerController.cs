using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private CharacterController characterController;
    private float moveSpeed = 10f;
    private float jumpForce = 5f;
    private float verticalVelocity = 0f;
    private float gravity = -9.81f;
    private bool isJumping = false;

    private PlayerCarInteraction carInteraction;
    private Camera mainCamera;

    private void Start()
    {
        characterController = GetComponent<CharacterController>();
        carInteraction = gameObject.AddComponent<PlayerCarInteraction>();
        mainCamera = Camera.main;
    }

    private void Update()
    {
        HandleMovement();
        HandleJump();
        HandleCarInteraction();
        UpdateCamera();
    }

    private void HandleMovement()
    {
        Vector3 moveDirection = Vector3.zero;

        if (Input.GetKey(KeyCode.W)) moveDirection += transform.forward;
        if (Input.GetKey(KeyCode.S)) moveDirection -= transform.forward;
        if (Input.GetKey(KeyCode.D)) moveDirection += transform.right;
        if (Input.GetKey(KeyCode.A)) moveDirection -= transform.right;

        if (moveDirection != Vector3.zero)
        {
            moveDirection.Normalize();
            characterController.Move(moveDirection * moveSpeed * Time.deltaTime);
        }

        // Rotate player based on mouse
        float mouseX = Input.GetAxis("Mouse X");
        transform.Rotate(0, mouseX * 2f, 0);
    }

    private void HandleJump()
    {
        if (characterController.isGrounded)
        {
            verticalVelocity = 0f;
            isJumping = false;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                verticalVelocity = jumpForce;
                isJumping = true;
            }
        }

        verticalVelocity += gravity * Time.deltaTime;
        characterController.Move(Vector3.up * verticalVelocity * Time.deltaTime);
    }

    private void HandleCarInteraction()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            carInteraction.TryEnterCar();
        }
    }

    private void UpdateCamera()
    {
        mainCamera.transform.position = transform.position + Vector3.up * 1.5f - transform.forward * 5 + Vector3.up * 3;
        mainCamera.transform.LookAt(transform.position + Vector3.up * 1f);
    }
}
