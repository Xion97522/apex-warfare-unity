using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private GameObject carPrefab;
    [SerializeField] private int carCount = 5;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        InitializeGame();
    }

    private void InitializeGame()
    {
        // Create terrain
        CreateTerrain();

        // Create sky
        CreateSky();

        // Spawn player
        SpawnPlayer();

        // Spawn cars
        SpawnCars();
    }

    private void CreateTerrain()
    {
        GameObject terrain = new GameObject("Terrain");
        
        // Create ground plane
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.transform.parent = terrain.transform;
        ground.transform.localScale = new Vector3(100, 1, 100);
        ground.transform.position = Vector3.zero;
        
        Material groundMat = new Material(Shader.Find("Standard"));
        groundMat.color = new Color(0.2f, 0.8f, 0.2f); // Green
        ground.GetComponent<Renderer>().material = groundMat;

        // Remove collider from ground primitive
        Collider groundCollider = ground.GetComponent<Collider>();
        if (groundCollider != null) DestroyImmediate(groundCollider);

        // Add box collider for physics
        BoxCollider groundPhysics = ground.AddComponent<BoxCollider>();
        groundPhysics.size = new Vector3(100, 1, 100);
    }

    private void CreateSky()
    {
        // Create sky
        Camera mainCamera = Camera.main;
        mainCamera.backgroundColor = new Color(0.5f, 0.8f, 1f); // Light blue sky

        // Optional: Create a sky sphere
        GameObject skySphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        skySphere.name = "Sky";
        skySphere.transform.localScale = new Vector3(1000, 1000, 1000);
        
        Material skyMat = new Material(Shader.Find("Standard"));
        skyMat.color = new Color(0.5f, 0.8f, 1f);
        skySphere.GetComponent<Renderer>().material = skyMat;

        // Remove collider
        Collider skyCollider = skySphere.GetComponent<Collider>();
        if (skyCollider != null) DestroyImmediate(skyCollider);

        // Keep camera inside sky sphere
        mainCamera.transform.parent = skySphere.transform;
    }

    private void SpawnPlayer()
    {
        Vector3 spawnPos = new Vector3(0, 2, 0);
        GameObject player = Instantiate(playerPrefab ?? CreatePlayerPrefab(), spawnPos, Quaternion.identity);
        player.name = "Player";
    }

    private void SpawnCars()
    {
        for (int i = 0; i < carCount; i++)
        {
            Vector3 spawnPos = new Vector3(i * 15, 2, i * 10);
            GameObject car = Instantiate(carPrefab ?? CreateCarPrefab(), spawnPos, Quaternion.identity);
            car.name = $"Car_{i}";
        }
    }

    private GameObject CreatePlayerPrefab()
    {
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Cube);
        player.name = "PlayerPrefab";
        player.transform.localScale = new Vector3(1, 2, 1);
        
        Material playerMat = new Material(Shader.Find("Standard"));
        playerMat.color = new Color(1f, 0.6f, 0f); // Orange
        player.GetComponent<Renderer>().material = playerMat;

        player.AddComponent<PlayerController>();
        player.AddComponent<CharacterController>();

        return player;
    }

    private GameObject CreateCarPrefab()
    {
        GameObject car = GameObject.CreatePrimitive(PrimitiveType.Cube);
        car.name = "CarPrefab";
        car.transform.localScale = new Vector3(2, 1.5f, 4);
        
        Material carMat = new Material(Shader.Find("Standard"));
        carMat.color = new Color(1f, 0f, 0f); // Red
        car.GetComponent<Renderer>().material = carMat;

        car.AddComponent<CarController>();
        car.AddComponent<Rigidbody>();

        return car;
    }
}
