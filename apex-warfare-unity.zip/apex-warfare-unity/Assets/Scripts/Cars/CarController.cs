using UnityEngine;

public class CarController : MonoBehaviour
{
    private Rigidbody rb;
    private float moveSpeed = 20f;
    private float turnSpeed = 100f;
    private Transform driver = null;
    private bool hasDriver = false;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
        }
        rb.mass = 1000f;
        rb.drag = 0.5f;
    }

    private void FixedUpdate()
    {
        if (hasDriver)
        {
            HandleDriving();
        }
    }

    private void HandleDriving()
    {
        // Forward/Backward
        float moveInput = 0f;
        if (Input.GetKey(KeyCode.W)) moveInput = 1f;
        if (Input.GetKey(KeyCode.S)) moveInput = -1f;

        // Left/Right
        float turnInput = 0f;
        if (Input.GetKey(KeyCode.D)) turnInput = 1f;
        if (Input.GetKey(KeyCode.A)) turnInput = -1f;

        // Apply movement
        rb.velocity = transform.forward * moveInput * moveSpeed;
        
        // Apply rotation
        transform.Rotate(0, turnInput * turnSpeed * Time.fixedDeltaTime, 0);

        // Update driver position
        if (driver != null)
        {
            driver.position = transform.position + Vector3.up * 1.5f;
            driver.rotation = transform.rotation;
        }
    }

    public void EnterCar(Transform player)
    {
        driver = player;
        hasDriver = true;
        player.GetComponent<CharacterController>().enabled = false;
    }

    public void ExitCar(Transform player)
    {
        hasDriver = false;
        player.transform.position = transform.position + Vector3.forward * 3 + Vector3.up * 0.5f;
        player.GetComponent<CharacterController>().enabled = true;
        driver = null;
    }
}
